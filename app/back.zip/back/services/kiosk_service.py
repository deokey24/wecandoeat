# app/back/services/kiosk_service.py
from __future__ import annotations


import secrets
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, TypedDict

from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.back.models.kiosk import Kiosk, KioskStatusLog, KioskEventLog
from app.back.models.vending import VendingSlot, VendingSlotProduct
from app.back.models.kiosk_product import KioskProduct  # 🔁 Product 대신 KioskProduct
from app.back.schemas.kiosk import KioskConfig, SlotConfig, KioskEventLogBatch



# =====================================================
# 🔹 원격배출 명령 (MVP용, 서버 메모리에만 저장)
# =====================================================

class _RemoteVendEntry(TypedDict):
    slot_id: int
    expires_at: datetime  # UTC 기준


# kiosk_id -> 원격배출 정보
_REMOTE_VEND_SLOTS: Dict[int, _RemoteVendEntry] = {}

# 로그TTL
LOG_RETENTION_DAYS = 3


def set_remote_vend_slot(kiosk_id: int, slot_id: int, ttl_seconds: int = 30) -> None:
    """
    관리자 페이지에서 원격배출 버튼을 눌렀을 때 호출.
    - 같은 키오스크에 대해 여러 번 눌러도 마지막 슬롯만 유지.
    - ttl_seconds 안에만 유효.
    """
    now = datetime.now(timezone.utc)
    _REMOTE_VEND_SLOTS[kiosk_id] = {
        "slot_id": slot_id,
        "expires_at": now + timedelta(seconds=ttl_seconds),
    }


def pop_remote_vend_slot(kiosk_id: int) -> Optional[int]:
    """
    키오스크 remote-ping 시에 1회용으로 소비하는 명령.
    - 유효시간이 지나면 자동 폐기하고 None 반환.
    """
    entry = _REMOTE_VEND_SLOTS.get(kiosk_id)
    if not entry:
        return None

    now = datetime.now(timezone.utc)
    if entry["expires_at"] < now:
        # 만료된 명령 → 삭제 후 무시
        _REMOTE_VEND_SLOTS.pop(kiosk_id, None)
        return None

    slot_id = entry["slot_id"]
    _REMOTE_VEND_SLOTS.pop(kiosk_id, None)
    return slot_id



async def get_by_id(db: AsyncSession, kiosk_id: int) -> Optional[Kiosk]:
    result = await db.execute(
        select(Kiosk)
        .options(
            selectinload(Kiosk.store),
            selectinload(Kiosk.screen_images),
        )
        .where(Kiosk.id == kiosk_id)
    )
    return result.scalar_one_or_none()


async def get_by_code(db: AsyncSession, code: str) -> Optional[Kiosk]:
    result = await db.execute(
        select(Kiosk)
        .options(
            selectinload(Kiosk.screen_images),
        )
        .where(Kiosk.code == code)
    )
    return result.scalar_one_or_none()


def generate_api_key() -> str:
    return secrets.token_urlsafe(32)


async def update_handshake(
    db: AsyncSession,
    kiosk: Kiosk,
    device_uuid: str,
    app_version: str,
    ip: Optional[str],
):
    kiosk.device_uuid = device_uuid
    kiosk.app_version = app_version
    kiosk.last_ip = ip
    kiosk.last_heartbeat_at = datetime.now(timezone.utc)

    if not kiosk.api_key:
        kiosk.api_key = generate_api_key()

    kiosk.updated_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(kiosk)


async def update_heartbeat(
    db: AsyncSession,
    kiosk: Kiosk,
    app_version: str,
    ip: Optional[str],
    status_payload: dict,
):
    kiosk.app_version = app_version
    kiosk.last_ip = ip
    kiosk.last_heartbeat_at = datetime.now(timezone.utc)
    kiosk.updated_at = datetime.now(timezone.utc)

    log = KioskStatusLog(
        kiosk_id=kiosk.id,
        status="ONLINE",
        payload=status_payload,
    )
    db.add(log)

    await db.commit()
    await db.refresh(kiosk)


async def build_config(db: AsyncSession, kiosk: Kiosk) -> KioskConfig:
    """
    키오스크에 연결된 슬롯 + 슬롯별 상품/재고 구성 정보
    - 내부 데이터는 kiosk_products 스냅샷 기준
    - JSON 구조는 기존 SlotConfig/KioskConfig 그대로 유지
    """
    stmt = (
        select(
            VendingSlot,
            VendingSlotProduct,
            KioskProduct,
        )
        .join(
            VendingSlotProduct,
            VendingSlotProduct.slot_id == VendingSlot.id,
            isouter=True,
        )
        .join(
            KioskProduct,
            KioskProduct.id == VendingSlotProduct.kiosk_product_id,
            isouter=True,
        )
        .where(VendingSlot.kiosk_id == kiosk.id)
    )

    result = await db.execute(stmt)
    rows = result.all()

    slots: List[SlotConfig] = []

    for slot, vsp, kp in rows:
        if vsp and kp:
            # 🔹 슬롯에 상품이 매핑된 경우 (kiosk_product 기준)
            slots.append(
                SlotConfig(
                    slot_id=slot.id,
                    board_code=slot.board_code,
                    row=slot.row,
                    col=slot.col,
                    label=slot.label,
                    max_capacity=slot.max_capacity,

                    # 상품 기본 정보 (이전에 Product에서 가져오던 필드들을 KioskProduct에서 그대로 사용)
                    product_id=kp.id,          # ← 앱에서 쓰는 ID (이제 kiosk_product.id)
                    product_name=kp.name,
                    price=kp.price,

                    # 성인 여부
                    is_adult_only=kp.is_adult_only,

                    # 이미지들
                    image_url=kp.image_url,
                    detail_image_url=kp.detail_url,

                    # 카테고리
                    category_code=kp.category,
                    category_name=kp.category,
                )
            )
        else:
            # 🔹 비어있는 슬롯
            slots.append(
                SlotConfig(
                    slot_id=slot.id,
                    board_code=slot.board_code,
                    row=slot.row,
                    col=slot.col,
                    label=slot.label,
                    max_capacity=slot.max_capacity,

                    product_id=None,
                    product_name=None,
                    price=None,
                    is_adult_only=None,
                    image_url=None,
                    detail_image_url=None,
                    category_code=None,
                    category_name=None,
                )
            )

    # 보호화면 이미지
    screensaver_images: List[str] = []
    if kiosk.screen_images:
        active_images = [i for i in kiosk.screen_images if i.is_active]
        for img in sorted(active_images, key=lambda x: x.sort_order or 0):
            screensaver_images.append(img.image_url)

    return KioskConfig(
        kiosk_id=kiosk.id,
        kiosk_name=kiosk.name,
        slots=slots,
        screensaver_images=screensaver_images,
    )


async def bump_config_version(db: AsyncSession, kiosk_id: int) -> None:
    kiosk = await db.get(Kiosk, kiosk_id)
    if not kiosk:
        return

    kiosk.config_version = (kiosk.config_version or 0) + 1
    kiosk.updated_at = datetime.now(timezone.utc)

    # 호출한 쪽에서 한 번에 commit 처리


async def save_kiosk_event_logs(
    db: AsyncSession,
    kiosk: Kiosk,
    batch: KioskEventLogBatch,
    keep_days: int = LOG_RETENTION_DAYS,
) -> int:
    """
    결제/배출(payAndVend) 이벤트 로그 배치 저장 + 3일 TTL 삭제
    """
    now = datetime.now(timezone.utc)

    if not batch.logs:
        return 0

    logs_to_add: list[KioskEventLog] = []

    for item in batch.logs:
        log = KioskEventLog(
            kiosk_id=kiosk.id,
            event_type=item.event_type,
            event_name=item.event_name,
            level=item.level,
            message=item.message,
            label_slot=item.label_slot,
            slot_label=item.slot_label,
            price_won=item.price_won,
            paid_won=item.paid_won,
            reason=item.reason,
            device_uuid=batch.device_uuid,
            app_version=batch.app_version,
            occurred_at=item.occurred_at,
        )
        logs_to_add.append(log)

    db.add_all(logs_to_add)

    # 3일 이전 로그 삭제 (created_at 기준)
    cutoff = now - timedelta(days=keep_days)
    await db.execute(
        delete(KioskEventLog)
        .where(KioskEventLog.kiosk_id == kiosk.id)
        .where(KioskEventLog.created_at < cutoff)
    )

    await db.commit()

    return len(logs_to_add)


